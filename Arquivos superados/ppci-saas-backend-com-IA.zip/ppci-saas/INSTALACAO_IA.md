# Guia de Instalação — Integração com IA Real (Anthropic Claude)

Este guia mostra como **plugar a IA real da Anthropic** no seu SaaS PPCI.
Tempo total: **15-30 minutos**.

---

## Como vai funcionar

```
   [HTML PPCI_SaaS.html]                [Backend FastAPI]              [API Anthropic]
   ┌────────────────┐                  ┌────────────────┐              ┌────────────────┐
   │  Você usa no   │  ──upload──▶     │  Recebe PDF/   │ ──API call──▶│  Claude lê,    │
   │  navegador     │                  │  imagem        │              │  analisa,      │
   │                │  ◀──JSON───      │  Encaminha     │ ◀──JSON─────│  retorna       │
   └────────────────┘   resultado      └────────────────┘   análise   └────────────────┘
```

---

## Etapa 1 — Obter chave da API Anthropic

1. Acesse https://console.anthropic.com
2. Crie sua conta (use o mesmo e-mail do Claude.ai se já tiver)
3. Vá em **Settings → API Keys → Create Key**
4. Copie a chave (formato: `sk-ant-api03-...`)
5. **Adicione créditos** em Billing (mínimo US$ 5 já dá pra muita análise)

### Custo estimado por análise

Usando o modelo **Claude Sonnet 4.6** (recomendado):

- PDF típico de planta (5-10 páginas): ~US$ 0,05 a US$ 0,15
- Imagem PNG/JPG: ~US$ 0,02 a US$ 0,05
- 100 análises por mês: ~US$ 5 a US$ 15

Modelos disponíveis no `.env`:
- `claude-sonnet-4-6` — recomendado (custo/benefício)
- `claude-opus-4-7` — mais preciso, ~5x mais caro
- `claude-haiku-4-5` — mais barato, menos detalhista

---

## Etapa 2 — Deploy do backend no Railway

Railway é o jeito mais fácil (~5 minutos).

### 2.1 — Subir código para o GitHub

1. Crie uma conta em https://github.com
2. Crie um repositório novo chamado `ppci-saas-backend` (privado, se preferir)
3. Faça upload da pasta `ppci-saas/` para o repositório (pode arrastar e soltar pela interface web)

### 2.2 — Deploy no Railway

1. Acesse https://railway.app e faça login com o GitHub
2. Clique em **"New Project" → "Deploy from GitHub repo"**
3. Selecione o repositório `ppci-saas-backend`
4. Railway detecta automaticamente Python e instala dependências
5. Vá em **Settings → Variables** e adicione:
   - Nome: `ANTHROPIC_API_KEY`
   - Valor: `sk-ant-api03-SUACHAVEAQUI` (a chave da Etapa 1)
6. Vá em **Settings → Networking → Generate Domain**
7. Copie a URL gerada (algo como `https://ppci-saas-backend-production.up.railway.app`)

### 2.3 — Testar se está funcionando

Abra no navegador:
```
https://SUA-URL.up.railway.app/api/health
```

Deve aparecer:
```json
{"status": "ok", "service": "PPCI SaaS API", "version": "1.0.0"}
```

E também:
```
https://SUA-URL.up.railway.app/api/ai/status
```

Deve aparecer:
```json
{"ai_enabled": true, "api_key_configured": true, "sdk_installed": true, "model_default": "claude-sonnet-4-6"}
```

Se `ai_enabled` estiver `false`, revise a variável `ANTHROPIC_API_KEY` no Railway.

---

## Etapa 3 — Conectar o HTML ao backend

1. Abra o `PPCI_SaaS.html` no navegador
2. Vá em **"Análise de Planta"** na sidebar
3. No canto superior direito, clique em **"Modo demo — configurar"**
4. Cole a URL do seu backend (passo 2.2.6): `https://SUA-URL.up.railway.app`
5. O sistema verifica e mostra ✓ **"Backend conectado · IA habilitada"**
6. O botão muda para verde: **"IA real conectada"**

A URL fica salva no navegador (localStorage). Não precisa configurar de novo.

---

## Etapa 4 — Usar a IA real

1. Faça upload de um PDF de planta (ou PNG/JPG de boa qualidade)
2. Clique em **"Analisar com IA"**
3. O sistema agora envia o arquivo para o backend, que chama o Claude
4. Aguarde 10-30 segundos (depende do tamanho do PDF)
5. Recebe análise REAL com confianças honestas

---

## Alternativas ao Railway

### Render.com (também gratuito para começar)
1. https://render.com → New → Web Service
2. Conecte ao GitHub
3. Configure:
   - Build Command: `pip install -r backend/requirements.txt`
   - Start Command: `uvicorn backend.main:app --host 0.0.0.0 --port $PORT`
4. Adicione `ANTHROPIC_API_KEY` em Environment Variables

### Localmente (para testar)
```bash
cd ppci-saas
pip install -r backend/requirements.txt
export ANTHROPIC_API_KEY=sk-ant-api03-suachave
uvicorn backend.main:app --host 0.0.0.0 --port 8000
```

No HTML, use a URL: `http://localhost:8000`

⚠️ Localmente só funciona com o backend rodando. Para uso "comercial", precisa deploy.

---

## Limitações e expectativas reais

### O que a IA faz BEM
- ✅ Ler **PDFs** de plantas com texto e cotas legíveis
- ✅ Analisar **imagens** (PNG/JPG) de plantas escaneadas
- ✅ Identificar quadros de áreas, memoriais, legendas
- ✅ Sugerir enquadramento conforme CBMBA
- ✅ Detectar sistemas PPCI representados graficamente

### O que a IA NÃO faz (e nunca prometa que faz)
- ❌ Ler arquivos **DWG/DXF/RVT/IFC** diretamente (são binários proprietários)
  - **Solução**: gerar PDF do projeto antes de fazer upload
- ❌ Calcular medidas precisas em mm/cm de plantas sem cotas
- ❌ Substituir a análise técnica do engenheiro responsável
- ❌ Garantir 100% de precisão — sempre marca confiança

### Para arquivos CAD/BIM
O backend retorna automaticamente uma mensagem orientando o usuário a:
1. Exportar PDF a partir do AutoCAD/Revit
2. Anexar o PDF para análise pela IA

Suporte nativo a CAD requer integração futura com bibliotecas (`ezdxf` para DXF,
`ifcopenshell` para IFC) ou plugin Revit dedicado.

---

## Custos detalhados (Claude Sonnet 4.6, preços de 2026)

- Input: US$ 3,00 por 1 milhão de tokens
- Output: US$ 15,00 por 1 milhão de tokens

Uma análise típica consome:
- Input: 5.000 a 20.000 tokens (PDF de 5-10 páginas) = **US$ 0,015 a US$ 0,06**
- Output: 1.500 a 3.000 tokens (JSON da análise) = **US$ 0,023 a US$ 0,045**
- **Total por análise: ~US$ 0,04 a US$ 0,11**

Para reduzir custos:
- Use Claude Haiku 4.5 (5x mais barato): mude `ANTHROPIC_MODEL=claude-haiku-4-5` no Railway
- Implemente cache de resultados (mesmo arquivo = mesma resposta)
- Limite upload a uma página por vez

---

## Troubleshooting

### "Backend inacessível"
- Verifique se o Railway está rodando (deve estar verde no dashboard)
- Cheque a URL: deve ter `https://` no início, sem barra no final
- CORS: o backend já está configurado para aceitar qualquer origem (`*`)

### "ai_enabled: false"
- A `ANTHROPIC_API_KEY` não foi configurada corretamente no Railway
- Vá em Variables, edite a chave, espere o redeploy automático

### "Erro 429" ou "rate limit"
- Sua conta Anthropic atingiu o limite de requisições
- Aguarde alguns minutos ou aumente o limite no Console Anthropic

### "Erro 401" ou "invalid API key"
- A chave foi copiada errada (com espaços) ou está expirada
- Gere uma nova chave em https://console.anthropic.com

### Resposta da IA estranha ou sem dados
- O PDF pode estar com baixa resolução ou sem texto extraível
- Tente uma versão melhor do PDF, ou converta para imagem PNG
- Aumente a temperatura do modelo (avançado): edite `plant_analysis.py`

---

## Próximos passos

Para evoluir o sistema:

1. **Cache** de respostas no Supabase (mesmo arquivo = mesma análise)
2. **Histórico** de análises por projeto
3. **Suporte CAD** com `ezdxf` para DXF nativo
4. **Plugin Revit** para enviar dados BIM diretamente
5. **Prompt fine-tuning** com exemplos de plantas reais aprovadas pelo CBMBA
