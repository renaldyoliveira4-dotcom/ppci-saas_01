"""
Serviço de análise de plantas com IA real (Anthropic Claude API).

Suporta:
- PDF nativo (até 32MB, 100 páginas) → Claude lê diretamente
- Imagens PNG/JPG/JPEG → Claude vision
- CAD (DWG/DXF/RVT/IFC) → não suportado nativamente; retorna mensagem clara

Requer variável de ambiente: ANTHROPIC_API_KEY
"""

import os
import base64
import json
import re
from typing import Optional

try:
    from anthropic import Anthropic, APIError
except ImportError:
    Anthropic = None
    APIError = Exception

from backend.ai.prompts import SYSTEM_PROMPT_PPCI


# Modelo recomendado para análise de plantas (boa visão + custo razoável)
# Sonnet 4.6 é o equilíbrio ideal entre capacidade e preço
MODEL_DEFAULT = "claude-sonnet-4-6"

MAX_TOKENS = 4096
PDF_MAX_BYTES = 32 * 1024 * 1024  # 32 MB
IMG_MAX_BYTES = 20 * 1024 * 1024  # 20 MB

SUPPORTED_PDF = {"application/pdf"}
SUPPORTED_IMG = {"image/png", "image/jpeg", "image/jpg", "image/webp", "image/gif"}
UNSUPPORTED_CAD = {".dwg", ".dxf", ".rvt", ".ifc"}


def _classificar_arquivo(filename: str, content_type: Optional[str] = None) -> dict:
    """Classifica o tipo de arquivo e seu método de processamento."""
    name = filename.lower()
    ext = "." + name.split(".")[-1] if "." in name else ""

    if ext == ".pdf" or content_type == "application/pdf":
        return {"tipo": "pdf", "media_type": "application/pdf"}
    if ext in {".png"} or content_type == "image/png":
        return {"tipo": "imagem", "media_type": "image/png"}
    if ext in {".jpg", ".jpeg"} or content_type in {"image/jpeg", "image/jpg"}:
        return {"tipo": "imagem", "media_type": "image/jpeg"}
    if ext == ".webp" or content_type == "image/webp":
        return {"tipo": "imagem", "media_type": "image/webp"}
    if ext in UNSUPPORTED_CAD:
        return {"tipo": "cad", "media_type": None}
    return {"tipo": "desconhecido", "media_type": None}


def _resposta_fallback_cad(filename: str) -> dict:
    """Resposta para arquivos CAD que o Claude não consegue ler nativamente."""
    ext = filename.split(".")[-1].upper() if "." in filename else "?"
    return {
        "confianca_geral": "pendente",
        "encontrados": [],
        "sistemas_identificados": [],
        "pendencias": [
            f"O arquivo {filename} (.{ext}) é um formato CAD/BIM que não pode ser lido diretamente pela IA.",
            "Para análise automática, exporte uma versão em PDF da planta com as pranchas técnicas.",
            "Recomendado: pranchas com quadro de áreas, cortes, plantas baixas dos pavimentos e legenda.",
        ],
        "inconsistencias": [
            {
                "tipo": "info",
                "texto": f"Para projetos {ext}, recomenda-se também fazer upload de PDF gerado a partir do mesmo arquivo, com as pranchas técnicas. A leitura nativa de {ext} requer integração BIM futura (plugin Revit / ifcopenshell).",
            }
        ],
        "sugestao_enquadramento": {
            "grupo": "",
            "divisao": "",
            "descricao": "Aguardando análise — envie PDF com pranchas técnicas",
            "risco": "PENDENTE",
            "processo": "Pendente",
            "justificativa": "Não foi possível analisar o arquivo CAD diretamente. Envie um PDF.",
            "its_aplicaveis": [],
        },
    }


def _resposta_erro(mensagem: str) -> dict:
    """Resposta padronizada para erros."""
    return {
        "confianca_geral": "baixa",
        "erro": mensagem,
        "encontrados": [],
        "sistemas_identificados": [],
        "pendencias": [mensagem, "Tente novamente ou contate o suporte."],
        "inconsistencias": [],
        "sugestao_enquadramento": {
            "grupo": "", "divisao": "", "descricao": "Erro na análise",
            "risco": "PENDENTE", "processo": "Erro", "justificativa": mensagem,
            "its_aplicaveis": [],
        },
    }


def _extrair_json(texto: str) -> Optional[dict]:
    """Extrai JSON do texto retornado pelo Claude, tolerando markdown."""
    if not texto:
        return None
    # Remove blocos markdown se vierem
    cleaned = re.sub(r"```(?:json)?\s*", "", texto)
    cleaned = re.sub(r"```\s*$", "", cleaned).strip()
    # Tenta parse direto
    try:
        return json.loads(cleaned)
    except json.JSONDecodeError:
        pass
    # Tenta achar o primeiro objeto JSON válido no texto
    match = re.search(r"\{.*\}", cleaned, re.DOTALL)
    if match:
        try:
            return json.loads(match.group())
        except json.JSONDecodeError:
            return None
    return None


def analisar_planta(
    arquivo_bytes: bytes,
    filename: str,
    content_type: Optional[str] = None,
    instrucoes_extras: Optional[str] = None,
    api_key: Optional[str] = None,
    model: str = MODEL_DEFAULT,
) -> dict:
    """
    Analisa uma planta PPCI usando IA real da Anthropic.

    Args:
        arquivo_bytes: bytes do arquivo (PDF ou imagem)
        filename: nome do arquivo (para detectar extensão)
        content_type: MIME type (opcional)
        instrucoes_extras: instruções adicionais do usuário (opcional)
        api_key: chave da API (opcional, padrão usa env ANTHROPIC_API_KEY)
        model: modelo Claude a usar

    Returns:
        dict com estrutura compatível com o frontend
    """
    if Anthropic is None:
        return _resposta_erro(
            "Biblioteca anthropic não instalada. Execute: pip install anthropic"
        )

    classificacao = _classificar_arquivo(filename, content_type)
    tipo = classificacao["tipo"]

    # CAD/BIM não precisam de API — resposta imediata orientando conversão
    if tipo == "cad":
        return _resposta_fallback_cad(filename)

    if tipo == "desconhecido":
        return _resposta_erro(
            f"Tipo de arquivo não suportado: {filename}. "
            "Formatos aceitos: PDF, PNG, JPG, WEBP."
        )

    # A partir daqui precisa de API key
    api_key = api_key or os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        return _resposta_erro(
            "Chave da API Anthropic não configurada. Defina ANTHROPIC_API_KEY."
        )

    # Validar tamanho
    tamanho = len(arquivo_bytes)
    if tipo == "pdf" and tamanho > PDF_MAX_BYTES:
        return _resposta_erro(
            f"PDF muito grande ({tamanho/1024/1024:.1f} MB). "
            f"Máximo: {PDF_MAX_BYTES/1024/1024:.0f} MB."
        )
    if tipo == "imagem" and tamanho > IMG_MAX_BYTES:
        return _resposta_erro(
            f"Imagem muito grande ({tamanho/1024/1024:.1f} MB). "
            f"Máximo: {IMG_MAX_BYTES/1024/1024:.0f} MB."
        )

    # Codifica em base64
    b64 = base64.standard_b64encode(arquivo_bytes).decode("utf-8")
    media_type = classificacao["media_type"]

    # Monta o content para a API
    if tipo == "pdf":
        content_block = {
            "type": "document",
            "source": {"type": "base64", "media_type": media_type, "data": b64},
        }
    else:  # imagem
        content_block = {
            "type": "image",
            "source": {"type": "base64", "media_type": media_type, "data": b64},
        }

    instrucao_usuario = (
        "Analise esta planta/documento técnico de edificação para dimensionamento PPCI. "
        "Extraia todos os dados visíveis, identifique sistemas de proteção representados, "
        "e sugira o enquadramento conforme as ITs do CBMBA. "
        "Responda APENAS com o JSON conforme especificado no system prompt."
    )
    if instrucoes_extras:
        instrucao_usuario += f"\n\nInstruções adicionais do usuário: {instrucoes_extras}"

    try:
        client = Anthropic(api_key=api_key)
        response = client.messages.create(
            model=model,
            max_tokens=MAX_TOKENS,
            system=SYSTEM_PROMPT_PPCI,
            messages=[
                {
                    "role": "user",
                    "content": [content_block, {"type": "text", "text": instrucao_usuario}],
                }
            ],
        )
    except APIError as e:
        return _resposta_erro(f"Erro da API Anthropic: {str(e)}")
    except Exception as e:
        return _resposta_erro(f"Erro inesperado: {type(e).__name__}: {str(e)}")

    # Extrai o texto da resposta
    texto_resposta = ""
    for block in response.content:
        if hasattr(block, "text"):
            texto_resposta += block.text

    # Tenta parsear JSON
    resultado = _extrair_json(texto_resposta)
    if not resultado:
        return _resposta_erro(
            f"IA retornou resposta não-JSON. Trecho: {texto_resposta[:200]}..."
        )

    # Adiciona metadados úteis
    resultado["_meta"] = {
        "model": model,
        "input_tokens": getattr(response.usage, "input_tokens", None),
        "output_tokens": getattr(response.usage, "output_tokens", None),
        "arquivo": filename,
        "tipo_arquivo": tipo,
    }

    return resultado
