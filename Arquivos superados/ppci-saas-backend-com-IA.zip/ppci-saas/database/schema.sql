-- ============================================================
-- PPCI SaaS - Schema do Banco de Dados (Supabase/PostgreSQL)
-- Baseado nas Instruções Técnicas do CBMBA
-- ============================================================

-- Habilitar extensões necessárias
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ============================================================
-- ENUM TYPES
-- ============================================================

CREATE TYPE tipo_processo AS ENUM ('PTS', 'PROJETO_TECNICO');
CREATE TYPE status_projeto AS ENUM ('RASCUNHO', 'EM_ANALISE', 'CALCULADO', 'APROVADO', 'ARQUIVADO');
CREATE TYPE tipo_risco AS ENUM ('LEVE', 'MODERADO', 'ELEVADO');
CREATE TYPE tipo_documento AS ENUM ('MEMORIAL', 'PLANILHA', 'RELATORIO_PDF');

-- ============================================================
-- TABELA: perfis (extensão do auth.users do Supabase)
-- ============================================================
CREATE TABLE perfis (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    nome_completo TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    telefone TEXT,
    empresa TEXT,
    crea_cau TEXT,
    plano TEXT DEFAULT 'FREE',
    avatar_url TEXT,
    criado_em TIMESTAMPTZ DEFAULT NOW(),
    atualizado_em TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- TABELA: projetos
-- ============================================================
CREATE TABLE projetos (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    usuario_id UUID NOT NULL REFERENCES perfis(id) ON DELETE CASCADE,
    nome TEXT NOT NULL,
    descricao TEXT,
    status status_projeto DEFAULT 'RASCUNHO',
    versao INTEGER DEFAULT 1,
    criado_em TIMESTAMPTZ DEFAULT NOW(),
    atualizado_em TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_projetos_usuario ON projetos(usuario_id);
CREATE INDEX idx_projetos_status ON projetos(status);

-- ============================================================
-- TABELA: edificacoes (dados técnicos da edificação)
-- ============================================================
CREATE TABLE edificacoes (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    projeto_id UUID NOT NULL REFERENCES projetos(id) ON DELETE CASCADE,
    nome_edificacao TEXT NOT NULL,
    endereco TEXT,
    cidade TEXT DEFAULT 'Salvador',
    estado TEXT DEFAULT 'BA',
    area_construida NUMERIC(12,2) NOT NULL,
    area_terreno NUMERIC(12,2),
    numero_pavimentos INTEGER NOT NULL DEFAULT 1,
    altura_edificacao NUMERIC(8,2) NOT NULL DEFAULT 0,
    ocupacao_grupo TEXT NOT NULL,
    ocupacao_divisao TEXT NOT NULL,
    ocupacao_descricao TEXT,
    populacao INTEGER,
    carga_incendio NUMERIC(10,2),
    possui_subsolo BOOLEAN DEFAULT FALSE,
    numero_subsolos INTEGER DEFAULT 0,
    tipo_risco tipo_risco,
    tipo_processo tipo_processo,
    responsavel_tecnico TEXT,
    crea_responsavel TEXT,
    observacoes TEXT,
    criado_em TIMESTAMPTZ DEFAULT NOW(),
    atualizado_em TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_edificacoes_projeto ON edificacoes(projeto_id);

-- ============================================================
-- TABELA: classificacoes (resultado da classificação)
-- ============================================================
CREATE TABLE classificacoes (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    edificacao_id UUID NOT NULL REFERENCES edificacoes(id) ON DELETE CASCADE,
    ocupacao_identificada TEXT,
    risco_identificado tipo_risco,
    tipo_processo tipo_processo,
    sistemas_exigidos JSONB DEFAULT '[]',
    norma_referencia TEXT,
    observacoes TEXT,
    calculado_em TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_classificacoes_edificacao ON classificacoes(edificacao_id);

-- ============================================================
-- TABELA: calculos_saida_emergencia
-- ============================================================
CREATE TABLE calculos_saida_emergencia (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    edificacao_id UUID NOT NULL REFERENCES edificacoes(id) ON DELETE CASCADE,
    populacao_pavimento INTEGER,
    capacidade_unidade_passagem NUMERIC(8,2),
    numero_saidas INTEGER,
    largura_minima_saida NUMERIC(8,2),
    largura_calculada NUMERIC(8,2),
    largura_adotada NUMERIC(8,2),
    distancia_maxima_percurso NUMERIC(8,2),
    tipo_escada TEXT,
    numero_escadas INTEGER,
    largura_escada NUMERIC(8,2),
    norma_referencia TEXT DEFAULT 'IT-11 CBMBA',
    dados_entrada JSONB,
    resultado JSONB,
    calculado_em TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- TABELA: calculos_extintores
-- ============================================================
CREATE TABLE calculos_extintores (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    edificacao_id UUID NOT NULL REFERENCES edificacoes(id) ON DELETE CASCADE,
    area_protegida NUMERIC(12,2),
    risco TEXT,
    tipo_extintor TEXT,
    capacidade_extintor TEXT,
    quantidade_calculada INTEGER,
    distancia_maxima_caminhamento NUMERIC(8,2),
    norma_referencia TEXT DEFAULT 'IT-04 CBMBA',
    dados_entrada JSONB,
    resultado JSONB,
    calculado_em TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- TABELA: calculos_hidrantes
-- ============================================================
CREATE TABLE calculos_hidrantes (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    edificacao_id UUID NOT NULL REFERENCES edificacoes(id) ON DELETE CASCADE,
    tipo_sistema TEXT,
    vazao_minima NUMERIC(10,2),
    pressao_minima NUMERIC(10,2),
    numero_hidrantes INTEGER,
    comprimento_mangueira NUMERIC(8,2),
    diametro_mangueira TEXT,
    tipo_esguicho TEXT,
    norma_referencia TEXT DEFAULT 'IT-17 CBMBA',
    dados_entrada JSONB,
    resultado JSONB,
    calculado_em TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- TABELA: calculos_reserva_tecnica
-- ============================================================
CREATE TABLE calculos_reserva_tecnica (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    edificacao_id UUID NOT NULL REFERENCES edificacoes(id) ON DELETE CASCADE,
    vazao_sistema NUMERIC(10,2),
    tempo_combate_minutos INTEGER DEFAULT 60,
    volume_calculado NUMERIC(12,2),
    volume_adotado NUMERIC(12,2),
    tipo_reservatorio TEXT,
    norma_referencia TEXT DEFAULT 'IT-17/IT-22 CBMBA',
    dados_entrada JSONB,
    resultado JSONB,
    calculado_em TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- TABELA: calculos_bombas_incendio
-- ============================================================
CREATE TABLE calculos_bombas_incendio (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    edificacao_id UUID NOT NULL REFERENCES edificacoes(id) ON DELETE CASCADE,
    vazao_necessaria NUMERIC(10,2),
    pressao_necessaria NUMERIC(10,2),
    potencia_calculada NUMERIC(10,2),
    potencia_adotada NUMERIC(10,2),
    tipo_bomba TEXT,
    bomba_jockey BOOLEAN DEFAULT FALSE,
    norma_referencia TEXT DEFAULT 'IT-22 CBMBA',
    dados_entrada JSONB,
    resultado JSONB,
    calculado_em TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- TABELA: documentos_gerados
-- ============================================================
CREATE TABLE documentos_gerados (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    projeto_id UUID NOT NULL REFERENCES projetos(id) ON DELETE CASCADE,
    tipo tipo_documento NOT NULL,
    nome_arquivo TEXT NOT NULL,
    url_arquivo TEXT,
    tamanho_bytes BIGINT,
    versao INTEGER DEFAULT 1,
    gerado_em TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_documentos_projeto ON documentos_gerados(projeto_id);

-- ============================================================
-- TABELA: versoes_projeto (histórico de versões)
-- ============================================================
CREATE TABLE versoes_projeto (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    projeto_id UUID NOT NULL REFERENCES projetos(id) ON DELETE CASCADE,
    numero_versao INTEGER NOT NULL,
    snapshot JSONB NOT NULL,
    descricao_alteracao TEXT,
    criado_em TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_versoes_projeto ON versoes_projeto(projeto_id);

-- ============================================================
-- ROW LEVEL SECURITY (RLS)
-- ============================================================

ALTER TABLE perfis ENABLE ROW LEVEL SECURITY;
ALTER TABLE projetos ENABLE ROW LEVEL SECURITY;
ALTER TABLE edificacoes ENABLE ROW LEVEL SECURITY;
ALTER TABLE classificacoes ENABLE ROW LEVEL SECURITY;
ALTER TABLE calculos_saida_emergencia ENABLE ROW LEVEL SECURITY;
ALTER TABLE calculos_extintores ENABLE ROW LEVEL SECURITY;
ALTER TABLE calculos_hidrantes ENABLE ROW LEVEL SECURITY;
ALTER TABLE calculos_reserva_tecnica ENABLE ROW LEVEL SECURITY;
ALTER TABLE calculos_bombas_incendio ENABLE ROW LEVEL SECURITY;
ALTER TABLE documentos_gerados ENABLE ROW LEVEL SECURITY;
ALTER TABLE versoes_projeto ENABLE ROW LEVEL SECURITY;

-- Políticas: cada usuário só vê seus próprios dados
CREATE POLICY "Usuarios veem proprio perfil" ON perfis
    FOR ALL USING (auth.uid() = id);

CREATE POLICY "Usuarios veem proprios projetos" ON projetos
    FOR ALL USING (auth.uid() = usuario_id);

CREATE POLICY "Usuarios veem proprias edificacoes" ON edificacoes
    FOR ALL USING (
        projeto_id IN (SELECT id FROM projetos WHERE usuario_id = auth.uid())
    );

CREATE POLICY "Usuarios veem proprias classificacoes" ON classificacoes
    FOR ALL USING (
        edificacao_id IN (
            SELECT e.id FROM edificacoes e
            JOIN projetos p ON e.projeto_id = p.id
            WHERE p.usuario_id = auth.uid()
        )
    );

CREATE POLICY "Usuarios veem proprios calculos saida" ON calculos_saida_emergencia
    FOR ALL USING (
        edificacao_id IN (
            SELECT e.id FROM edificacoes e
            JOIN projetos p ON e.projeto_id = p.id
            WHERE p.usuario_id = auth.uid()
        )
    );

CREATE POLICY "Usuarios veem proprios calculos extintores" ON calculos_extintores
    FOR ALL USING (
        edificacao_id IN (
            SELECT e.id FROM edificacoes e
            JOIN projetos p ON e.projeto_id = p.id
            WHERE p.usuario_id = auth.uid()
        )
    );

CREATE POLICY "Usuarios veem proprios calculos hidrantes" ON calculos_hidrantes
    FOR ALL USING (
        edificacao_id IN (
            SELECT e.id FROM edificacoes e
            JOIN projetos p ON e.projeto_id = p.id
            WHERE p.usuario_id = auth.uid()
        )
    );

CREATE POLICY "Usuarios veem proprias reservas" ON calculos_reserva_tecnica
    FOR ALL USING (
        edificacao_id IN (
            SELECT e.id FROM edificacoes e
            JOIN projetos p ON e.projeto_id = p.id
            WHERE p.usuario_id = auth.uid()
        )
    );

CREATE POLICY "Usuarios veem proprias bombas" ON calculos_bombas_incendio
    FOR ALL USING (
        edificacao_id IN (
            SELECT e.id FROM edificacoes e
            JOIN projetos p ON e.projeto_id = p.id
            WHERE p.usuario_id = auth.uid()
        )
    );

CREATE POLICY "Usuarios veem proprios documentos" ON documentos_gerados
    FOR ALL USING (
        projeto_id IN (SELECT id FROM projetos WHERE usuario_id = auth.uid())
    );

CREATE POLICY "Usuarios veem proprias versoes" ON versoes_projeto
    FOR ALL USING (
        projeto_id IN (SELECT id FROM projetos WHERE usuario_id = auth.uid())
    );

-- ============================================================
-- TRIGGERS para atualizar timestamps
-- ============================================================

CREATE OR REPLACE FUNCTION atualizar_timestamp()
RETURNS TRIGGER AS $$
BEGIN
    NEW.atualizado_em = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_perfis_atualizado
    BEFORE UPDATE ON perfis
    FOR EACH ROW EXECUTE FUNCTION atualizar_timestamp();

CREATE TRIGGER trigger_projetos_atualizado
    BEFORE UPDATE ON projetos
    FOR EACH ROW EXECUTE FUNCTION atualizar_timestamp();

CREATE TRIGGER trigger_edificacoes_atualizado
    BEFORE UPDATE ON edificacoes
    FOR EACH ROW EXECUTE FUNCTION atualizar_timestamp();

-- ============================================================
-- FUNCTION: criar perfil automaticamente no signup
-- ============================================================

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO public.perfis (id, nome_completo, email)
    VALUES (
        NEW.id,
        COALESCE(NEW.raw_user_meta_data->>'nome_completo', NEW.email),
        NEW.email
    );
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER on_auth_user_created
    AFTER INSERT ON auth.users
    FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();
