// supabase/functions/kiwify-webhook/index.ts
// Recebe o webhook (postback) da Kiwify e libera/revoga o plano do usuário no Supabase.
// Deploy:  supabase functions deploy kiwify-webhook --no-verify-jwt
// Secrets: supabase secrets set KIWIFY_TOKEN=xxxxx   (token do webhook, no painel da Kiwify)

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { createHmac } from "node:crypto";

// ── Mapa: ID do produto na Kiwify → plano no app ───────────────────────────────
// Pegue o ID na URL do produto: dashboard.kiwify.com.br/products/edit/<ID>
const PRODUTO_PLANO: Record<string, "pro" | "escritorio"> = {
  // "ID_DO_PRODUTO_PROFISSIONAL": "pro",
  // "ID_DO_PRODUTO_ESCRITORIO":   "escritorio",
};
// Se você só tem 1 produto hoje (o do link BHLRqDV), deixe o padrão como "pro":
const PLANO_PADRAO: "pro" | "escritorio" = "pro";

// Dias de validade após o pagamento (mensal = 31; anual = 366)
const DIAS_VALIDADE = 31;

const KIWIFY_TOKEN = Deno.env.get("KIWIFY_TOKEN") ?? "";
const supabase = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
);

// A Kiwify assina o corpo com HMAC-SHA1 usando o token, e envia em ?signature=
function assinaturaValida(signature: string | null, corpo: string): boolean {
  if (!signature || !KIWIFY_TOKEN) return false;
  const esperada = createHmac("sha1", KIWIFY_TOKEN).update(corpo).digest("hex");
  return signature === esperada;
}

Deno.serve(async (req) => {
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405 });

  const url = new URL(req.url);
  const corpo = await req.text();

  if (!assinaturaValida(url.searchParams.get("signature"), corpo)) {
    return new Response("Assinatura inválida", { status: 401 });
  }

  let e: any;
  try { e = JSON.parse(corpo); } catch { return new Response("JSON inválido", { status: 400 }); }

  // A Kiwify varia os nomes dos campos conforme o evento — leitura defensiva:
  const status = String(
    e.order_status ?? e.subscription_status ?? e.webhook_event_type ?? "",
  ).toLowerCase();
  const email = String(
    e.Customer?.email ?? e.customer?.email ?? e.email ?? "",
  ).toLowerCase().trim();
  const produtoId = e.Product?.product_id ?? e.product_id ?? e.Product?.id ?? "";

  // Sempre responda 200 nos casos "ignoráveis" para a Kiwify não reenviar infinitamente.
  if (!email) return new Response("ok (sem email)", { status: 200 });

  const aprovado = ["paid", "approved", "aprovada", "renewed", "renovada", "active"]
    .some((s) => status.includes(s));
  const cancelado = ["refund", "reembols", "chargeback", "cancel", "late", "atrasada"]
    .some((s) => status.includes(s));

  let plano: "free" | "pro" | "escritorio" | null = null;
  let expira: string | null = null;

  if (aprovado) {
    plano = PRODUTO_PLANO[produtoId] ?? PLANO_PADRAO;
    const d = new Date(); d.setDate(d.getDate() + DIAS_VALIDADE);
    expira = d.toISOString();
  } else if (cancelado) {
    plano = "free";
    expira = null;
  } else {
    return new Response("ok (evento ignorado: " + status + ")", { status: 200 });
  }

  // Encontra o usuário pelo e-mail (precisa ser o mesmo e-mail do login no app).
  const { data: list } = await supabase.auth.admin.listUsers();
  const user = list?.users?.find((u) => (u.email ?? "").toLowerCase() === email);
  if (!user) return new Response("ok (usuário não encontrado: " + email + ")", { status: 200 });

  const { error } = await supabase
    .from("profiles")
    .update({ plan: plano, plan_expires_at: expira, updated_at: new Date().toISOString() })
    .eq("id", user.id);

  if (error) return new Response("Erro ao atualizar: " + error.message, { status: 500 });

  return new Response(JSON.stringify({ ok: true, email, plan: plano }), {
    headers: { "Content-Type": "application/json" },
  });
});
