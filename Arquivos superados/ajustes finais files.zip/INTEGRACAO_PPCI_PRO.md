# PPCI PRO IA — O que falta para entrar no ar

## ✅ Já está pronto (verificado no seu Supabase)

O backend está mais completo do que parecia. No projeto **PPCI SaaS** (`sduzuhdeiyvwsoblrpke`):

- Tabela **`profiles`** com RLS ligado e as policies `SELECT` e `UPDATE` (cada um vê/edita só o próprio).
  Já tem as colunas `plan` (free / pro / escritorio), `plan_expires_at`, `projects_count`, `crea_cau`, etc.
- Tabela **`projects`** com RLS ligado e as policies `SELECT`, `INSERT`, `UPDATE`, `DELETE` (cada um só nos próprios).
- Gatilho **`on_auth_user_created`** → cria o perfil automaticamente quando alguém se cadastra.
- Gatilhos de `updated_at` nas duas tabelas.
- Autenticação completa no app (login, cadastro, recuperação de senha, sessão).

**Ou seja: banco, segurança e login estão prontos. Nada a criar no Supabase.**

---

## ⚠️ O que falta (tudo no FRONTEND, mais o webhook de pagamento)

### 1. O app NÃO está salvando os projetos no banco
Hoje ele **lê** os projetos do Supabase, mas ao criar/editar/excluir só mexe na memória
(`setProjects(...)`). Recarregou a página → perdeu. Falta ligar o `insert`/`update`/`delete`.

Há também uma **diferença de nomes** entre o app e o banco:

| No app (memória)        | Na tabela `projects` |
|-------------------------|----------------------|
| `area_construida`       | `area`               |
| `altura_edificacao`     | `altura`             |
| `numero_pavimentos`     | `pavimentos`         |
| `possui_subsolo`        | `subterraneo`        |
| `grupo` (não há coluna)  | → guardar em `calculos` (jsonb) |

**Solução (sem mexer no banco):** dois conversores + handlers de salvar/excluir.
Cole isto dentro do componente `App` (perto de onde já existe o `supabase.from("projects").select(...)`):

```js
// ---- conversores app <-> banco ----
const dbToApp = (r) => ({
  id: r.id, nome: r.nome, status: r.status,
  area_construida: r.area, altura_edificacao: r.altura,
  numero_pavimentos: r.pavimentos, possui_subsolo: r.subterraneo,
  divisao: r.divisao, populacao: r.populacao, carga_incendio: r.carga_incendio,
  endereco: r.endereco, sistemas: r.sistemas || [],
  // campos que só existem no app ficam dentro de calculos (jsonb):
  ...(r.calculos || {}),
});
const appToDb = (p, userId) => ({
  user_id: userId, nome: p.nome, endereco: p.endereco || null,
  divisao: p.divisao, area: Number(p.area_construida) || 0,
  pavimentos: Number(p.numero_pavimentos) || 1, altura: Number(p.altura_edificacao) || 3,
  subterraneo: !!p.possui_subsolo, populacao: Number(p.populacao) || null,
  carga_incendio: Number(p.carga_incendio) || null,
  sistemas: p.sistemas || [],
  calculos: {
    grupo: p.grupo, numero_subsolos: p.numero_subsolos,
    responsavel_tecnico: p.responsavel_tecnico, crea_responsavel: p.crea_responsavel,
    areas_por_pavimento: p.areas_por_pavimento, calculos: p.calculos,
  },
});

// salvar (cria ou atualiza) — retorna o projeto já com id do banco
const salvarProjeto = async (p) => {
  const userId = session.user.id;
  if (p.id && typeof p.id === "string") {            // já existe no banco
    const { data, error } = await supabase.from("projects")
      .update(appToDb(p, userId)).eq("id", p.id).select().single();
    if (error) { alert("Erro ao salvar: " + error.message); return p; }
    return dbToApp(data);
  } else {                                            // novo
    const { data, error } = await supabase.from("projects")
      .insert(appToDb(p, userId)).select().single();
    if (error) { alert("Erro ao salvar: " + error.message); return p; }
    return dbToApp(data);
  }
};
const excluirProjeto = async (id) => {
  await supabase.from("projects").delete().eq("id", id);
  setProjects((prev) => prev.filter((x) => x.id !== id));
};
```

E no `select` que já existe, troque `setProjects(data)` por:
```js
setProjects((data || []).map(dbToApp));
```

Depois, em **NovoProjetoPage**, na função `criar`, em vez de `setProjects(p=>[n,...p])`, use:
```js
const salvo = await salvarProjeto(n);
setProjects((p) => [salvo, ...p]);
setSelProj(salvo);
setPage("calculos");
```
E ligue `excluirProjeto(p.id)` no botão de excluir do Dashboard (no lugar do filter local).

### 2. Trava do plano gratuito (3 projetos)
No `criar`, antes de salvar:
```js
if (plano === "free" && projects.length >= 3) {
  setPage("planos-bloqueio"); // ou abra o checkout da Kiwify
  return;
}
```

### 3. Pagamento via Kiwify (substitui o Stripe — sim!)
Veja a seção abaixo.

---

## 💳 Kiwify substitui o Stripe? **Sim.**

A Kiwify é gateway + checkout hospedado (acaba sendo mais simples que Stripe no Brasil:
aceita Pix, boleto e cartão, e o checkout é pronto). Você **não constrói** tela de pagamento —
só manda o cliente para o seu link:

```
https://pay.kiwify.com.br/BHLRqDV
```

O que muda em relação ao Stripe: em vez da API da Stripe + Stripe Checkout, você usa
o **link da Kiwify** + o **webhook da Kiwify** para liberar o plano. A peça que faz isso
é a Edge Function `kiwify-webhook.ts` (entregue junto).

### Como ligar (passo a passo)

1. **Botões "Assinar" no app e na landing** → apontam para `https://pay.kiwify.com.br/BHLRqDV`.
   Dica: peça para o cliente pagar com **o mesmo e-mail** que ele usa no login do app
   (é por ele que o webhook identifica quem liberar). Opcional: passar o e-mail na URL.

2. **Deploy do webhook** (a função já está pronta no arquivo `kiwify-webhook.ts`):
   ```bash
   # coloque o arquivo em supabase/functions/kiwify-webhook/index.ts
   supabase functions deploy kiwify-webhook --no-verify-jwt --project-ref sduzuhdeiyvwsoblrpke
   supabase secrets set KIWIFY_TOKEN=SEU_TOKEN_DO_WEBHOOK --project-ref sduzuhdeiyvwsoblrpke
   ```
   A URL final fica:
   `https://sduzuhdeiyvwsoblrpke.supabase.co/functions/v1/kiwify-webhook`

3. **Na Kiwify** (menu Apps → Webhooks → Criar webhook):
   - URL: a URL acima
   - Produtos: o seu produto
   - Eventos: **Compra aprovada, Reembolso, Chargeback, Assinatura Renovada, Cancelada e Atrasada**
   - Copie o **token** que a Kiwify mostra e use no `supabase secrets set KIWIFY_TOKEN=...`

4. Se tiver **2 planos** (Profissional e Escritório), crie 2 produtos na Kiwify e preencha o
   mapa `PRODUTO_PLANO` no topo do `kiwify-webhook.ts` com os IDs. Com 1 produto só, o padrão `pro` resolve.

Fluxo final: cliente paga na Kiwify → Kiwify chama o webhook → a função acha o usuário pelo
e-mail e marca `plan = pro` (e `plan_expires_at`). Em reembolso/cancelamento, volta para `free`.

---

## Sobre a sua lista de custos (revisada)

- **Domínio (Hostinger ~R$50/ano):** necessário. ✅
- **Vercel (R$0):** hospeda o frontend estático. ✅
- **DigitalOcean (R$30/mês):** **dá pra cortar.** O webhook roda como Edge Function no próprio
  Supabase; não precisa de servidor separado por enquanto.
- **Supabase Pro (R$138/mês):** opcional no início — o **free** roda. Suba para Pro quando
  tiver clientes (evita o projeto pausar por inatividade + backups).
- **Kiwify:** entra no lugar da Stripe. Você paga a taxa da Kiwify só quando vende.

**Mínimo para faturar:** aplicar o patch do item 1 (salvar projetos), ligar o webhook da Kiwify
(item 3) e publicar no Vercel com o domínio. O resto é melhoria.
